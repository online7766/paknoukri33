<div class="airlift">
	<div id="main-page">
		<section id="header">
			<div class="custom-container">
				<?php require_once dirname( __FILE__ ) . "/components/header_top.php"; ?>
			</div>
		</section>
		<?php
			require_once dirname( __FILE__ ) . "/components/list_accounts.php";
		?>
	</div>
</div>